﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DemoNhomCSDL.Context;

namespace DemoNhomCSDL.Areas.Admin.Controllers
{
    public class VePhim_AdminController : Controller
    {
        private QL_BANVEntities db = new QL_BANVEntities();

        // GET: Admin/VePhim_Admin
        public async Task<ActionResult> Index()
        {
            var vEPHIM = db.VEPHIM.Include(v => v.GHE1).Include(v => v.KHACHHANG).Include(v => v.LOAIVE).Include(v => v.NHANVIEN).Include(v => v.PHIM).Include(v => v.PHONGCHIEU).Include(v => v.XUATCHIEU1);
            return View(await vEPHIM.ToListAsync());
        }

        // GET: Admin/VePhim_Admin/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VEPHIM vEPHIM = await db.VEPHIM.FindAsync(id);
            if (vEPHIM == null)
            {
                return HttpNotFound();
            }
            return View(vEPHIM);
        }

        // GET: Admin/VePhim_Admin/Create
        public ActionResult Create()
        {
            ViewBag.Ghe = new SelectList(db.GHE, "MaGhe", "TenGhe");
            ViewBag.MaKH = new SelectList(db.KHACHHANG, "MaKH", "HoKH");
            ViewBag.MaLoaiVe = new SelectList(db.LOAIVE, "MaLV", "TenLoaiVe");
            ViewBag.MaNV = new SelectList(db.NHANVIEN, "MaNV", "HoNV");
            ViewBag.MaPhim = new SelectList(db.PHIM, "MaPhim", "MaLP");
            ViewBag.MaPhong = new SelectList(db.PHONGCHIEU, "MaPhong", "TenPhong");
            ViewBag.XuatChieu = new SelectList(db.XUATCHIEU, "MaXuatChieu", "MaPhim");
            return View();
        }

        // POST: Admin/VePhim_Admin/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "MaVe,MaNV,MaKH,MaLoaiVe,MaPhim,MaPhong,Ghe,XuatChieu,GiaVe,NgayBan")] VEPHIM vEPHIM)
        {
            if (ModelState.IsValid)
            {
                db.VEPHIM.Add(vEPHIM);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.Ghe = new SelectList(db.GHE, "MaGhe", "TenGhe", vEPHIM.Ghe);
            ViewBag.MaKH = new SelectList(db.KHACHHANG, "MaKH", "HoKH", vEPHIM.MaKH);
            ViewBag.MaLoaiVe = new SelectList(db.LOAIVE, "MaLV", "TenLoaiVe", vEPHIM.MaLoaiVe);
            ViewBag.MaNV = new SelectList(db.NHANVIEN, "MaNV", "HoNV", vEPHIM.MaNV);
            ViewBag.MaPhim = new SelectList(db.PHIM, "MaPhim", "MaLP", vEPHIM.MaPhim);
            ViewBag.MaPhong = new SelectList(db.PHONGCHIEU, "MaPhong", "TenPhong", vEPHIM.MaPhong);
            ViewBag.XuatChieu = new SelectList(db.XUATCHIEU, "MaXuatChieu", "MaPhim", vEPHIM.XuatChieu);
            return View(vEPHIM);
        }

        // GET: Admin/VePhim_Admin/Edit/5
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VEPHIM vEPHIM = await db.VEPHIM.FindAsync(id);
            if (vEPHIM == null)
            {
                return HttpNotFound();
            }
            ViewBag.Ghe = new SelectList(db.GHE, "MaGhe", "TenGhe", vEPHIM.Ghe);
            ViewBag.MaKH = new SelectList(db.KHACHHANG, "MaKH", "HoKH", vEPHIM.MaKH);
            ViewBag.MaLoaiVe = new SelectList(db.LOAIVE, "MaLV", "TenLoaiVe", vEPHIM.MaLoaiVe);
            ViewBag.MaNV = new SelectList(db.NHANVIEN, "MaNV", "HoNV", vEPHIM.MaNV);
            ViewBag.MaPhim = new SelectList(db.PHIM, "MaPhim", "MaLP", vEPHIM.MaPhim);
            ViewBag.MaPhong = new SelectList(db.PHONGCHIEU, "MaPhong", "TenPhong", vEPHIM.MaPhong);
            ViewBag.XuatChieu = new SelectList(db.XUATCHIEU, "MaXuatChieu", "MaPhim", vEPHIM.XuatChieu);
            return View(vEPHIM);
        }

        // POST: Admin/VePhim_Admin/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "MaVe,MaNV,MaKH,MaLoaiVe,MaPhim,MaPhong,Ghe,XuatChieu,GiaVe,NgayBan")] VEPHIM vEPHIM)
        {
            if (ModelState.IsValid)
            {
                db.Entry(vEPHIM).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            ViewBag.Ghe = new SelectList(db.GHE, "MaGhe", "TenGhe", vEPHIM.Ghe);
            ViewBag.MaKH = new SelectList(db.KHACHHANG, "MaKH", "HoKH", vEPHIM.MaKH);
            ViewBag.MaLoaiVe = new SelectList(db.LOAIVE, "MaLV", "TenLoaiVe", vEPHIM.MaLoaiVe);
            ViewBag.MaNV = new SelectList(db.NHANVIEN, "MaNV", "HoNV", vEPHIM.MaNV);
            ViewBag.MaPhim = new SelectList(db.PHIM, "MaPhim", "MaLP", vEPHIM.MaPhim);
            ViewBag.MaPhong = new SelectList(db.PHONGCHIEU, "MaPhong", "TenPhong", vEPHIM.MaPhong);
            ViewBag.XuatChieu = new SelectList(db.XUATCHIEU, "MaXuatChieu", "MaPhim", vEPHIM.XuatChieu);
            return View(vEPHIM);
        }

        // GET: Admin/VePhim_Admin/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VEPHIM vEPHIM = await db.VEPHIM.FindAsync(id);
            if (vEPHIM == null)
            {
                return HttpNotFound();
            }
            return View(vEPHIM);
        }

        // POST: Admin/VePhim_Admin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            VEPHIM vEPHIM = await db.VEPHIM.FindAsync(id);
            db.VEPHIM.Remove(vEPHIM);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
