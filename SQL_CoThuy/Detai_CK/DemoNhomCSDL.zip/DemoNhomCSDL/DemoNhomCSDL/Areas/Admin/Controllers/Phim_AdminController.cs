﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DemoNhomCSDL.Context;

namespace DemoNhomCSDL.Areas.Admin.Controllers
{
    public class Phim_AdminController : Controller
    {
        private QL_BANVEntities db = new QL_BANVEntities();

        // GET: Admin/Phim_Admin
        public ActionResult Index()
        {
            var pHIM = db.PHIM.Include(p => p.DANGPHIM).Include(p => p.DSDIENVIEN).Include(p => p.LOAIPHIM);
            return View(pHIM.ToList());
        }
        string LayMaPhim()
        {
            // Lấy danh sách mã phim từ cơ sở dữ liệu
            var maPhims = db.PHIM.ToList().Select(n => n.MaPhim).ToList();

            // Nếu không có phim nào trong cơ sở dữ liệu, bắt đầu từ MP001
            if (maPhims.Count == 0)
            {
                return "MP001";
            }

            // Tìm mã phim lớn nhất hiện có
            var maMax = maPhims.Max();

            // Tách phần số từ mã phim
            int number = int.Parse(maMax.Substring(2));

            // Tăng giá trị số lên 1
            number++;

            // Tạo mã phim mới với định dạng MPXXX
            string newMaPhim = "MP" + number.ToString("D3");

            return newMaPhim;
        }

        // GET: Admin/Phim_Admin/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PHIM pHIM = db.PHIM.Find(id);
            if (pHIM == null)
            {
                return HttpNotFound();
            }
            return View(pHIM);
        }

        // GET: Admin/Phim_Admin/Create
        public ActionResult Create()
        {
            ViewBag.MaPhim = LayMaPhim();
            ViewBag.MaDP = new SelectList(db.DANGPHIM, "MaDP", "DangPhim1");
            ViewBag.MaDSDV = new SelectList(db.DSDIENVIEN, "MaDSDV", "DanhSachDienVien");
            ViewBag.MaLP = new SelectList(db.LOAIPHIM, "MaLP", "LoaiPhim1"); // Phải là SelectList

            return View();
        }


        // POST: Admin/Phim_Admin/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaPhim,MaLP,MaDP,TenPhim,DaoDien,NgayKhoiChieu,MaDSDV,ThoiLuong,MoTaPhim,TinhTrang,DoTuoi,AnhPhim")] PHIM pHIM)
        {
            var imgNV = Request.Files["Avatar"];
           

            // Tiếp tục nếu không có lỗi
            string postedFileName = System.IO.Path.GetFileName(imgNV.FileName);
            var path = Server.MapPath("~/images/film/" + postedFileName);
            imgNV.SaveAs(path);

            if (ModelState.IsValid)
            {
                pHIM.MaPhim = LayMaPhim();
                pHIM.AnhPhim = postedFileName;
                db.PHIM.Add(pHIM);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            // Nếu có lỗi trong ModelState, gán lại SelectLists
            ViewBag.MaDP = new SelectList(db.DANGPHIM, "MaDP", "DangPhim1", pHIM.MaDP);
            ViewBag.MaDSDV = new SelectList(db.DSDIENVIEN, "MaDSDV", "DanhSachDienVien", pHIM.MaDSDV);
            ViewBag.MaLP = new SelectList(db.LOAIPHIM, "MaLP", "LoaiPhim1", pHIM.MaLP);

            return View(pHIM);
        }




        // GET: Admin/Phim_Admin/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PHIM pHIM = db.PHIM.Find(id);
            if (pHIM == null)
            {
                return HttpNotFound();
            }
            ViewBag.MaDP = new SelectList(db.DANGPHIM, "MaDP", "DangPhim1", pHIM.MaDP);
            ViewBag.MaDSDV = new SelectList(db.DSDIENVIEN, "MaDSDV", "DanhSachDienVien", pHIM.MaDSDV);
            ViewBag.MaLP = new SelectList(db.LOAIPHIM, "MaLP", "LoaiPhim1", pHIM.MaLP);
            return View(pHIM);
        }

        // POST: Admin/Phim_Admin/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaPhim,MaLP,MaDP,TenPhim,DaoDien,NgayKhoiChieu,MaDSDV,ThoiLuong,MoTaPhim,TinhTrang,DoTuoi,AnhPhim")] PHIM pHIM)
        {
            var imgPhim = Request.Files["Avatar"];
            try
            {
                //Lấy thông tin từ input type=file có tên Avatar
                string postedFileName = System.IO.Path.GetFileName(imgPhim.FileName);
                //Lưu hình đại diện về Server
                var path = Server.MapPath("~/images/film/" + postedFileName);
                imgPhim.SaveAs(path);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                db.Entry(pHIM).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaDP = new SelectList(db.DANGPHIM, "MaDP", "DangPhim1", pHIM.MaDP);
            ViewBag.MaDSDV = new SelectList(db.DSDIENVIEN, "MaDSDV", "DanhSachDienVien", pHIM.MaDSDV);
            ViewBag.MaLP = new SelectList(db.LOAIPHIM, "MaLP", "LoaiPhim1", pHIM.MaLP);
            return View(pHIM);
        }

        // GET: Admin/Phim_Admin/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PHIM pHIM = db.PHIM.Find(id);
            if (pHIM == null)
            {
                return HttpNotFound();
            }
            return View(pHIM);
        }

        // POST: Admin/Phim_Admin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            PHIM pHIM = db.PHIM.Find(id);
            db.PHIM.Remove(pHIM);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
