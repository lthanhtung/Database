﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DemoNhomCSDL.Context;

namespace DemoNhomCSDL.Areas.Admin.Controllers
{
    public class DangPhim_AdminController : Controller
    {
        private QL_BANVEntities db = new QL_BANVEntities();

        // GET: Admin/DangPhim_Admin
        public async Task<ActionResult> Index()
        {
            return View(await db.DANGPHIM.ToListAsync());
        }

        // GET: Admin/DangPhim_Admin/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DANGPHIM dANGPHIM = await db.DANGPHIM.FindAsync(id);
            if (dANGPHIM == null)
            {
                return HttpNotFound();
            }
            return View(dANGPHIM);
        }

        // GET: Admin/DangPhim_Admin/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/DangPhim_Admin/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "MaDP,DangPhim1")] DANGPHIM dANGPHIM)
        {
            if (ModelState.IsValid)
            {
                db.DANGPHIM.Add(dANGPHIM);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(dANGPHIM);
        }

        // GET: Admin/DangPhim_Admin/Edit/5
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DANGPHIM dANGPHIM = await db.DANGPHIM.FindAsync(id);
            if (dANGPHIM == null)
            {
                return HttpNotFound();
            }
            return View(dANGPHIM);
        }

        // POST: Admin/DangPhim_Admin/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "MaDP,DangPhim1")] DANGPHIM dANGPHIM)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dANGPHIM).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(dANGPHIM);
        }

        // GET: Admin/DangPhim_Admin/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DANGPHIM dANGPHIM = await db.DANGPHIM.FindAsync(id);
            if (dANGPHIM == null)
            {
                return HttpNotFound();
            }
            return View(dANGPHIM);
        }

        // POST: Admin/DangPhim_Admin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            DANGPHIM dANGPHIM = await db.DANGPHIM.FindAsync(id);
            db.DANGPHIM.Remove(dANGPHIM);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
