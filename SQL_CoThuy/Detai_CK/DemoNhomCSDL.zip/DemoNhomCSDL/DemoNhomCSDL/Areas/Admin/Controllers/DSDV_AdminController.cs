﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DemoNhomCSDL.Context;

namespace DemoNhomCSDL.Areas.Admin.Controllers
{
    public class DSDV_AdminController : Controller
    {
        private QL_BANVEntities db = new QL_BANVEntities();

        // GET: Admin/DSDV_Admin
        public async Task<ActionResult> Index()
        {
            return View(await db.DSDIENVIEN.ToListAsync());
        }

        // GET: Admin/DSDV_Admin/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DSDIENVIEN dSDIENVIEN = await db.DSDIENVIEN.FindAsync(id);
            if (dSDIENVIEN == null)
            {
                return HttpNotFound();
            }
            return View(dSDIENVIEN);
        }

        // GET: Admin/DSDV_Admin/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/DSDV_Admin/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "MaDSDV,DanhSachDienVien")] DSDIENVIEN dSDIENVIEN)
        {
            if (ModelState.IsValid)
            {
                db.DSDIENVIEN.Add(dSDIENVIEN);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(dSDIENVIEN);
        }

        // GET: Admin/DSDV_Admin/Edit/5
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DSDIENVIEN dSDIENVIEN = await db.DSDIENVIEN.FindAsync(id);
            if (dSDIENVIEN == null)
            {
                return HttpNotFound();
            }
            return View(dSDIENVIEN);
        }

        // POST: Admin/DSDV_Admin/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "MaDSDV,DanhSachDienVien")] DSDIENVIEN dSDIENVIEN)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dSDIENVIEN).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(dSDIENVIEN);
        }

        // GET: Admin/DSDV_Admin/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DSDIENVIEN dSDIENVIEN = await db.DSDIENVIEN.FindAsync(id);
            if (dSDIENVIEN == null)
            {
                return HttpNotFound();
            }
            return View(dSDIENVIEN);
        }

        // POST: Admin/DSDV_Admin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            DSDIENVIEN dSDIENVIEN = await db.DSDIENVIEN.FindAsync(id);
            db.DSDIENVIEN.Remove(dSDIENVIEN);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
